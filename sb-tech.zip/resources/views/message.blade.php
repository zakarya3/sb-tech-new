<h3>De : {{ $name }}</h3>
<h3>Email : {{ $email }}</h3>
<h3>Téléphone : {{ $phone }}</h3>
<h3>Sujet : {{ $subject }}</h3>
<p>{{ $message1 }}</p>