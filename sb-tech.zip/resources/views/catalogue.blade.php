<h2>Bonjour mr. {{ $name }}</h2>
<h2>Vous pouvez télécharger le catalogue <a href="https://www.mediafire.com/file/kply01oj9wuwjhp/Catalogue.pdf/file" download>ici</a></h2>