<h2>Téléchargement du catalogue Par: <br></h2>
<h4>Nom : {{ $name }}</h4>
<h4>E-mail : {{ $email }}</h4>
<h4>Entreprise : {{ $company }}</h4>