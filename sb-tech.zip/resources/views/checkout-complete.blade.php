@extends('layouts.navbar')
      <!-- Hero (Banners + Slider)-->
      @section('content')
      <div class="container pb-5 mb-sm-4">
        <div class="pt-5">
          <div class="card py-3 mt-sm-3">
            <div class="card-body text-center">
              <h2 class="h4 pb-3">VOTRE COMMANDE EST CONFIRMÉE</h2>
              <p class="fs-sm mb-2">Un e-mail vous a été envoyé à l'adresse <strong>{{ $user->email }}</strong>.</p>
            </div>
          </div>
        </div>
      </div>

      @endsection