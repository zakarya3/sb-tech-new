<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use App\Models\Product;
use App\Models\User;
use App\Models\Order;
use App\Models\OrderItem;

class UserController extends Controller
{
    public function index(Request $request)
    {
        if ($request->session()->has('name')) {
            $cartItems = \Cart::getContent();
            $user = User::where('name',$request->session()->get('name'))->first();
            $orders = Order::where('user_id',$user->id)->orderBy('created_at','desc')->get();      
            return view('orders',compact('orders','cartItems'));
        }else {
            return redirect()->back();
        }
    }
    public function view(Request $request, $id)
    {
        $cartItems = \Cart::getContent();
        $user = User::where('name',$request->session()->get('name'))->first();
        $userid = $user->id;
        $order = Order::where('id',$id)->where('user_id', $userid)->first();
        $orders = OrderItem::where('order_id',$order->id)->get();
        return view('view',compact('orders','user','order','cartItems'));
    }
}