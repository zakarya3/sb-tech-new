
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-primary">
                <h4 class="card-title ">Liste des produits</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>ID</th>
                      <th>Nom</th>
                      <th>E-mail</th>
                      <th>Téléphone</th>
                      <th>Adresse</th>
                      <th>Role</th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->address); ?></td>
                        <td>
                            <?php if($item->role_as == 1): ?>
                                admin
                              <?php elseif($item->role_as == 3): ?>
                                Employeur
                                <?php elseif($item->role_as == 4): ?>
                                  Stagiaire
                                  <?php elseif($item->role_as == 0): ?>
                                  Client
                                    <?php elseif($item->role_as == 2): ?>
                                    Station
                            <?php endif; ?>
                          </td>
                        <td>
                          <?php if(Auth::user()->role_as == 1 || Auth::user()->role_as == 3): ?>
                          <a href="<?php echo e(url('edit-usr/'.$item->id)); ?>" class="btn btn-primary pull-righ">Modifier</a>
                          <a href="<?php echo e(url('delete-usr/'.$item->id)); ?>" class="btn bg-danger pull-righ" style="color: white">Supprimer</a>
                          <?php endif; ?>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin/users/index.blade.php ENDPATH**/ ?>