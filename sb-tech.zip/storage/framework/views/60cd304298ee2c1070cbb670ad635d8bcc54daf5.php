<head>
    <style>
    table, th, td {
      border: 1px solid;
    }
    </style>
</head>


<h3>vous avez une commande <?php echo e($trackin); ?> de <?php echo e($user_name); ?> </h3>
<h3>Adresse : <?php echo e($address); ?></h3>
<h3>Date : <?php echo e($date); ?></h3>
<h3>Prix Total : <?php echo e($price); ?> MAD</h3>
<?php if($choice == 0): ?>
    <h3>Mode de paiement : Par chèque</h3>
<?php else: ?>
    <h3>Mode de paiemnt : Payer comptant à la livraison</h3>
<?php endif; ?>
<table>
    <tr>
      <th>Nom</th>
      <th>Coût unitaire</th>
      <th>Quantité</th>
      <th>Montant</th>
    </tr>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->product->product_name); ?></td>
        <td><?php echo e($item->price); ?></td>
        <td><?php echo e($item->qty); ?></td>
        <td><?php echo e($item->price * $item->qty); ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<a href="<?php echo e(url('http://127.0.0.1:8000/admin/view-order/'.$id)); ?>">Pour plus de détails</a><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin-mail.blade.php ENDPATH**/ ?>