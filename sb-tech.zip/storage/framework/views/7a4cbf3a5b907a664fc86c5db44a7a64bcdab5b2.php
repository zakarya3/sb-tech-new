

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
          <div class="col-md-8">
            <div class="card">
              <div class="card-header card-header-primary">
                <h4 class="card-title">Modifier un produit</h4>
                <p class="card-products">Produits</p>
              </div>
              <div class="card-body">
                <form action="<?php echo e(url('update-product/'.$products->id)); ?>" method="post"enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <div class="row">
                    <label for="">Categorie</label>
                    <select class="form-select" required  name="cate_id">
                        <option value="<?php echo e($products->category->id); ?>"><?php echo e($products->category->name); ?></option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="row">
                    <label for="">Marque</label>
                    <select class="form-select"  name="brand">
                      <option value="<?php echo e($products->brand->id); ?>"><?php echo e($products->brand->brand_name); ?></option>
                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->brand_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="bmd-label-floating">Nom du produit</label>
                        <input type="text" name="title" value="<?php echo e($products->product_name); ?>"  class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="bmd-label-floating">Quantité</label>
                        <input type="number" name="qty" value="<?php echo e($products->qty); ?>"  class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="bmd-label-floating">Prix</label>
                        <input type="number" name="price" value="<?php echo e($products->price); ?>"  class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="bmd-label-floating">Référence</label>
                        <input type="text" name="ref" value="<?php echo e($products->product_reference); ?>"  class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="input-group mb-3">
                        <?php if($products->image): ?>
                        <img src="<?php echo e(asset('assets/uploads/products/images/'.$products->image)); ?>" alt="">
                        <?php endif; ?>
                        <label class="input-group-text" for="image">Image</label>
                        <input type="file"  name="image" class="form-control" id="image">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="input-group mb-3">
                        <?php if($products->fiche): ?>
                        <a href="<?php echo e(url('assets/uploads/products/ficheTechnique/'.$products->fich)); ?>" download alt=""></a>
                        <?php endif; ?>
                        <label class="input-group-text" for="image">Fiche Technique</label>
                        <input type="file"  name="fiche" class="form-control" id="image">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <textarea name="description" id="" cols="30" rows="10"><?php echo e($products->product_description); ?></textarea>
                    </div>
                  </div>
                  <button type="submit" class="btn btn-primary pull-right">Modifier</button>
                  <div class="clearfix"></div>
                </form>
              </div>
            </div>
          </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>