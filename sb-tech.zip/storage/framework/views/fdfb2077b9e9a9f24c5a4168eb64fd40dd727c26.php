

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Ajouter une categorie</h4>
                  <p class="card-category">Categories</p>
                </div>
                <div class="card-body">
                  <form action="<?php echo e(url('insert-category')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Categorie</label>
                          <input type="text" class="form-control" required name="name">
                        </div>
                      </div>
                    </div>
                    <button type="submit" class="btn btn-primary pull-right">Ajouter</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title ">Liste des categories</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table">
                        <thead class=" text-primary">
                          <th>
                            ID
                          </th>
                          <th>
                            Name
                          </th>
                        </thead>
                        <tbody>
                         <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td>
                              <?php echo e($item->id); ?>

                            </td>
                            <td>
                              <?php echo e($item->name); ?>

                            </td>
                            <td>
                               <?php if(Auth::user()->role_as == 1 || Auth::user()->role_as == 3): ?>
                               <a type="submit" class="btn btn-primary pull-right" href="<?php echo e(url('edit-cat/'.$item->id)); ?>">Modifier</a>
                               <a type="submit" class="btn bg-danger pull-right" style="color: white" href="<?php echo e(url('delete-category/'.$item->id)); ?>">Supprimer</a>
                               <?php endif; ?>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin/category/index.blade.php ENDPATH**/ ?>