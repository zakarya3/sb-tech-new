

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Ajouter une marque</h4>
                  <p class="card-category">Marques</p>
                </div>
                <div class="card-body">
                  <form action="<?php echo e(url('insert-brand')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Nom de la marque</label>
                          <input type="text" class="form-control" required name="name">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                          <div class="input-group mb-3">
                            <label class="input-group-text" for="image">Image</label>
                            <input type="file" required name="image" class="form-control" id="image">
                          </div>
                        </div>
                      </div>
                    <button type="submit" class="btn btn-primary pull-right">Ajouter</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title ">Liste des marques</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table">
                        <thead class=" text-primary">
                            <tr>
                                <th>ID</th>
                                <th>Nom de la brand</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($item->id); ?></td>
                                  <td><?php echo e($item->brand_name); ?></td>
                                  <td>
                                    <?php if(Auth::user()->role_as == 1 || Auth::user()->role_as == 3): ?>
                                    <a href="<?php echo e(url('edit-brand/'.$item->id)); ?>" class="btn btn-primary pull-righ">Modifier</a>
                                    <a href="<?php echo e(url('delete-brand/'.$item->id)); ?>" class="btn bg-danger pull-righ" style="color: white">Supprimer</a>
                                    <?php endif; ?>
                                  </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin/brands/index.blade.php ENDPATH**/ ?>