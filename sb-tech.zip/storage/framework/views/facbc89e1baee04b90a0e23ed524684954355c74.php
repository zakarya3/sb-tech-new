
      <!-- Hero (Banners + Slider)-->
      <?php $__env->startSection('content'); ?>
      <div class="container pb-5 mb-sm-4">
        <div class="pt-5">
          <div class="card py-3 mt-sm-3">
            <div class="card-body text-center">
              <h2 class="h4 pb-3">VOTRE COMMANDE EST CONFIRMÉE</h2>
              <p class="fs-sm mb-2">Un e-mail vous a été envoyé à l'adresse <strong><?php echo e($user->email); ?></strong>.</p>
            </div>
          </div>
        </div>
      </div>

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/checkout-complete.blade.php ENDPATH**/ ?>