

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Modifier la marque</h4>
                  <p class="card-category">Marques</p>
                </div>
                <div class="card-body">
                  <form action="<?php echo e(url('update-brand/'.$brand->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Nom de la marque</label>
                          <input type="text" class="form-control" value="<?php echo e($brand->brand_name); ?>" required name="name">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                          <div class="input-group mb-3">
                            <?php if($brand->image): ?>
                            <img src="<?php echo e(asset('assets/uploads/brands/images/'.$brand->image)); ?>" alt="">
                            <?php endif; ?>
                            <label class="input-group-text" for="image">Image</label>
                            <input type="file" required name="image" class="form-control" id="image">
                          </div>
                        </div>
                      </div>
                    <button type="submit" class="btn btn-primary pull-right">Modifier</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin/brands/edit.blade.php ENDPATH**/ ?>