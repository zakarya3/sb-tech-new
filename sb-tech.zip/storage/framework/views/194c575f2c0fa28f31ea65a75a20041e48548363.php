<h2>Téléchargement du catalogue Par: <br></h2>
<h4>Nom : <?php echo e($name); ?></h4>
<h4>E-mail : <?php echo e($email); ?></h4>
<h4>Entreprise : <?php echo e($company); ?></h4><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin-cata.blade.php ENDPATH**/ ?>