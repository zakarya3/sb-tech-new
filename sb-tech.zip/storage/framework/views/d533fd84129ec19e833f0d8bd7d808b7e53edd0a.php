
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6" style="width: 35%">
                <label class="form-label" for="">Nom</label>
                <div class="form-control"style= "border: none !important"><?php echo e($orders->fname); ?></div>
                <label class="form-label" for="">Prenom</label>
                <div class="form-control"style= "border: none !important"><?php echo e($orders->lname); ?></div>
                <label class="form-label" for="">Email</label>
                <div class="form-control"style= "border: none !important"><?php echo e($orders->email); ?></div>
                <label class="form-label" for="">Téléphone</label>
                <div class="form-control"style= "border: none !important"><?php echo e($orders->phone); ?></div>
                <label class="form-label" for="">Adresse</label>
                <div class="form-control"style= "border: none !important"><?php echo e($orders->address); ?></div>
            </div>
            <div class="col-md-6" style="width: 65%">
                <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Produit</th>
                          <th>Quantité</th>
                          <th>Prix</th>
                          <th>Image</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $orders->orderitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($item->product->product_name); ?></td>
                            <td><?php echo e($item->qty); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <td>
                               <img src="<?php echo e(asset('assets/uploads/products/images/'.$item->product->image)); ?>" style="width: 50px" alt="">
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    <h6>Prix Total : <?php echo e($orders->total_price); ?> MAD</h6>
                    <a class="btn btn-outline-primary btn-sm ps-2" href="<?php echo e(url('orders')); ?>"><i class="ci-arrow-left me-2"></i>Les commandes</a>
                    <div class="mt-3 px-2">
                        <label for="">Statut de la commande</label>
                        <form action="<?php echo e(url('update-order/'.$orders->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <select class="form-select" name="order_status">
                                <option <?php echo e($orders->status == '0' ? 'selected':''); ?> value="0" >en attendant</option>
                                <option <?php echo e($orders->status == '1' ? 'selected':''); ?> value="1" >complété</option>
                              </select>
                              <button type="submit" class="btn btn-primary mt-3">Modifier</button>
                        </form>
                    </div>
                  </div>
            </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin/orders/view.blade.php ENDPATH**/ ?>