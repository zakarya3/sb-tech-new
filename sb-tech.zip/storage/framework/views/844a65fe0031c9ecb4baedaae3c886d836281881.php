<h3>De : <?php echo e($name); ?></h3>
<h3>Email : <?php echo e($email); ?></h3>
<h3>Téléphone : <?php echo e($phone); ?></h3>
<h3>Sujet : <?php echo e($subject); ?></h3>
<p><?php echo e($message1); ?></p><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/message.blade.php ENDPATH**/ ?>