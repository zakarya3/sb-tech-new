
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <h6>Commandes
        <a href="<?php echo e(url('order-history')); ?>" style="color: white" class="btn bg-warning float-end">Historique des commandes</a>
      </h6>
      <hr>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
                <th>Date</th>
                <th>Numéro de suivi</th>
                <th>Prix total</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item->created_at); ?></td>
                <td><?php echo e($item->tracking_no); ?></td>
                <td><?php echo e($item->total_price); ?></td>
                <td><?php echo e($item->status == '0' ? 'en attendant' : 'complété'); ?></td>
                <td>
                    <a href="<?php echo e(url('admin/view-order/'.$item->id)); ?>" class="btn btn-primary">Vue</a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>