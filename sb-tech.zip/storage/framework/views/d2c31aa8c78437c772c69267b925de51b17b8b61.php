
<?php $__env->startSection('content'); ?>
<section class="container">


    <div class="ttp">
        <!-- Breadcrumb -->
        <nav class="pt-4 mt-lg-3" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('/')); ?>"><i class="bx bx-home-alt fs-lg me-1"></i>Accueil</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('/cart')); ?>">Panier</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Vérification</li>
            </ol>
        </nav>


        <!-- Page title + Filters -->
        <div class="d-lg-flex align-items-center justify-content-between py-4 mt-lg-2">
            <h1 class="me-3">Vérification des informations</h1>
            <div class="d-md-flex mb-3">
                <a class="btn btn-outline-primary btn-sm ps-2" href="<?php echo e(url('/')); ?>"><i
                        class='bx bx-chevron-left'></i>Continue shopping</a>
            </div>
        </div>
    </div>
    <div class="container pb-5 mb-2 mb-md-4">
        <div class="row">
            <!-- List of items-->
            <section class="col-lg-8">
                <form action="<?php echo e(url('payment')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_token" value="3r2BsNcJtyRfjStGB4IHk8ky1EsoApGD64jBfxfV">
                    <h2 class="h6 pt-1 pb-3 mb-3 border-bottom">Adresse de livraison</h2>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <label class="form-label" for="checkout-fn">Nom &amp; Prénom</label>
                                <input class="form-control" required="" name="userName" value="<?php if($user!=NULL): ?><?php echo e($user->name); ?><?php endif; ?>" type="text"
                                    id="checkout-fn">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label class="form-label" for="checkout-phone">Numéro de téléphone</label>
                                    <input class="form-control" required="" name="phone" value="<?php if($user!=NULL): ?><?php echo e($user->phone); ?><?php endif; ?>" type="text"
                                        id="checkout-phone">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label class="form-label" for="checkout-address-1">Adresse</label>
                                    <input class="form-control" required="" name="address" value="<?php if($user!=NULL): ?><?php echo e($user->address); ?><?php endif; ?>" type="text"
                                        id="checkout-address-1">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label class="form-label" for="checkout-email">Adresse e-mail</label>
                                    <input class="form-control" required="" name="email" value="<?php if($user!=NULL): ?><?php echo e($user->email); ?><?php endif; ?>" type="email"
                                        id="checkout-email">
                                </div>
                            </div>
                        </div>
                        <div class="d-none d-lg-flex pt-4 mt-3">
                            <div class="w-50 pe-3"><a class="btn btn-secondary d-block w-100" href="<?php echo e(url('cart')); ?>"><i class='bx bx-chevron-left'></i><span class="d-none d-sm-inline">Retour au panier</span><span class="d-inline d-sm-none">Back</span></a></div>
                            <div class="w-50 ps-2"><button class="btn btn-primary d-block w-100" type="submit"><span class="d-none d-sm-inline">Confirmer</span><span class="d-inline d-sm-none">Next</span><i class='bx bx-chevron-right mt-sm-0 ms-1'></i></button>
                            </div>
                        </div>
                    </div>
                    </section>
                    <!-- Sidebar-->
                    <aside class="col-lg-4 pt-4 pt-lg-0 ps-xl-5">
                        <div class="card">
                        <div class="card-body">
                            <h6>Détails</h6>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">
                                <thead>
                                    <tr>
                                    <th>Produit</th>
                                    <th>Qty</th>
                                    <th>Prix</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $total = 0;
                                    ?>
                                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->quantity); ?></td>
                                        <td><?php echo e($item->price); ?> <small>MAD</small></td>
                                    </tr>
                                    <?php
                                        $total += $item->price * $item->quantity
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <th>Total TTC</th>
                                    <td><?php echo e($total); ?></td>
                                    <input type="hidden" name="total" value="<?php echo e($total); ?>">
                                    <td>MAD</td>
                                    </tr>
                                </tbody>
                                </table>
                            </div>
                        </div>
                        </div>
                    </aside>
                    <div class="row d-lg-none">
                        <div class="col-lg-8">
                        <div class="d-flex pt-4 mt-3">
                            <div class="w-50 pe-3"><a class="btn btn-secondary d-block w-100" href="<?php echo e(url('cart')); ?>"><i class='bx bx-chevron-left me-1'></i><span class="d-none d-sm-inline">Retour au panier</span><span class="d-inline d-sm-none">Retour au panier</span></a></div>
                            <div class="w-50 ps-2"><button class="btn btn-primary d-block w-100" type="submit"><span class="d-none d-sm-inline">Confirmer</span><span class="d-inline d-sm-none">Confirmer</span><i class='bx bx-chevron-right mt-sm-0 ms-1'></i></button></div>
                        </div>
                        </div>

                    </div>
                </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/checkout.blade.php ENDPATH**/ ?>