

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
          <div class="col-md-8">
            <div class="card">
              <div class="card-header card-header-primary">
                <h4 class="card-title">Modifier référence</h4>
                <p class="card-products">références</p>
              </div>
              <div class="card-body">
                <form action="<?php echo e(url('update-reference/'.$references->id)); ?>" method="post"enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <div class="row">
                    <label for="">Categorie</label>
                    <select class="form-select" required  name="categ_id">
                        <option value="">select a category</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="bmd-label-floating">Titre du Référence</label>
                        <input type="text" name="title" value="<?php echo e($references->title); ?>" required class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="bmd-label-floating">Date</label>
                        <input type="date" name="date" value="<?php echo e($references->date); ?>" required class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="input-group mb-3">
                        <?php if($references->image): ?>
                        <img src="<?php echo e(asset('assets/uploads/references/images/'.$references->image)); ?>" alt="">
                        <?php endif; ?>
                        <label class="input-group-text" for="image">Image</label>
                        <input type="file"  name="image" class="form-control" id="image">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <textarea name="description" id="" cols="30" rows="10"><?php echo e($references->description); ?></textarea>
                    </div>
                  </div>
                  <button type="submit" class="btn btn-primary pull-right">Modifier</button>
                  <div class="clearfix"></div>
                </form>
              </div>
            </div>
          </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/admin/reference/edit.blade.php ENDPATH**/ ?>