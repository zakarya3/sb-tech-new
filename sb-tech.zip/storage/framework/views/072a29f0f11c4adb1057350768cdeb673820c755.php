<?php echo $__env->yieldContent('content'); ?>
</main>

<!-- Footer -->
<footer class="footer dark-mode bg-dark pt-5 pb-4 pb-lg-5">
  <div class="container pt-lg-4">
    <div class="row pb-5">
      <div class="col-lg-4 col-md-6">
        <div class="navbar-brand text-dark p-0 me-0 mb-3 mb-lg-4">
          <img src="assets/img/logo/logo.png" width="150" alt="SB-TECH" />
        </div>
        
        <p class="fs-sm text-light opacity-70 pb-lg-3 mb-4">
          <i class='bx bx-map'></i> Bureau N 1 .Av Prince Abdelkader N 78 Cite Almassira Agadir <br> 
          <i class='bx bxs-phone'></i> <a href="tel:+212 528 217 355">+212 528 217 355</a>
        </p>
        <form class="needs-validation" novalidate>
          <label for="subscr-email" class="form-label">Subscribe to our
            newsletter</label>
          <div class="input-group">
            <input type="email" id="subscr-email" class="form-control rounded-start ps-5" placeholder="Your email"
              required />
            <i class="bx bx-envelope fs-lg text-muted position-absolute
                top-50 start-0 translate-middle-y ms-3 zindex-5"></i>
            <div class="invalid-tooltip position-absolute top-100 start-0">
              Please provide a valid email address.
            </div>
            <button type="submit" class="btn btn-primary">Subscribe</button>
          </div>
        </form>
      </div>
      <div class="col-xl-6 col-lg-7 col-md-5 offset-xl-2 offset-md-1 pt-4
          pt-md-1 pt-lg-0">
        <div id="footer-links" class="row">
          <div class="col-lg-4">
            <h6 class="mb-2">
              <a href="#useful-links" class="d-block text-dark dropdown-toggle d-lg-none py-2"
                data-bs-toggle="collapse">Useful Links</a>
            </h6>
            <div id="useful-links" class="collapse d-lg-block" data-bs-parent="#footer-links">
              <ul class="nav flex-column pb-lg-1 mb-lg-3">
                <li class="nav-item">
                  <a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Accueil</a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Contactez-nous!!</a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Références</a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Produits</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-xl-4 col-lg-3">
            <h6 class="mb-2">
              <a href="#social-links" class="d-block text-dark dropdown-toggle d-lg-none py-2"
                data-bs-toggle="collapse">Socials</a>
            </h6>
            <div id="social-links" class="collapse d-lg-block" data-bs-parent="#footer-links">
              <ul class="nav flex-column mb-2 mb-lg-0">
                <li class="nav-item">
                  <a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2"><i class="bx bxl-linkedin"></i></a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2"><i class="bx bxl-facebook"></i></a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2"><i class="bx bxl-instagram"></i></a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2"><i class="bx bxl-gmail"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-xl-4 col-lg-5 pt-2 pt-lg-0">
            <h6 class="mb-2">Contact Us</h6>
            <a href="mailto:info@sbtech.ma" class="fw-medium"><i class="bx bxl-gmail"></i> info@sbtech.ma</a>
          </div>
        </div>
      </div>
    </div>
    <p class="fs-xs text-center text-md-start pb-2 pb-lg-0 mb-0">
      <span class="text-light opacity-50">&copy; All rights reserved. Made
        by
      </span>
      <a class="nav-link d-inline-block p-0" href="" target="_blank" rel="noopener"> SB-TECH</a>
    </p>
  </div>
</footer>

<!-- Back to top button -->
<a href="#top" class="btn-scroll-top" data-scroll>
  <span class="btn-scroll-top-tooltip text-muted fs-sm me-2">Top</span>
  <i class="btn-scroll-top-icon bx bx-chevron-up"></i>
</a>

<!-- Vendor Scripts -->
<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/smooth-scroll.polyfills.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/swiper-bundle.min.js')); ?>"></script>

<!-- Main Theme Script -->
<script src="<?php echo e(asset('frontend/js/theme.min.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/layouts/footer.blade.php ENDPATH**/ ?>