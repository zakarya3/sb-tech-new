
<?php $__env->startSection('content'); ?>
<section class="container">


    <div class="ttp">
        <!-- Breadcrumb -->
        <nav class="pt-4 mt-lg-3" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('/')); ?>"><i class="bx bx-home-alt fs-lg me-1"></i>Accueil</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Ma commande</li>
            </ol>
        </nav>


        <!-- Page title + Filters -->
        <div class="d-lg-flex align-items-center justify-content-between py-4 mt-lg-2">
            <h1 class="me-3">Ma commande</h1>
            <div class="d-md-flex mb-3">
                <a class="btn btn-outline-primary btn-sm ps-2" href="<?php echo e(url('/')); ?>"><i
                        class='bx bx-chevron-left'></i>Continue shopping</a>
            </div>
        </div>
    </div>
    <div class="container pb-5 mb-2 mb-md-4">
        <div class="row">
          <!-- List of items-->
          <section class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label" for="">Nom & Prénom</label>
                            <div class="form-control"><?php echo e($user->name); ?></div>
                            <label class="form-label" for="">Email</label>
                            <div class="form-control"><?php echo e($user->email); ?></div>
                            <label class="form-label" for="">Téléphone</label>
                            <div class="form-control"><?php echo e($user->phone); ?></div>
                            <label class="form-label" for="">Adresse</label>
                            <div class="form-control"><?php echo e($user->address); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="table-responsive">
                                <table class="table">
                                  <thead>
                                    <tr>
                                      <th>Produit</th>
                                      <th>Quantité</th>
                                      <th>Prix</th>
                                      <th>Image</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td><?php echo e($item->product->product_name); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e($item->price); ?></td>
                                        <td>
                                           <img src="<?php echo e(asset('assets/uploads/products/images/'.$item->product->image)); ?>" style="width: 50px" alt="">
                                        </td>
                                      </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                                </table>
                                <h6>Prix Total : <?php echo e($order->total_price); ?> MAD</h6>
                                <a class="btn btn-outline-primary btn-sm ps-2" href="<?php echo e(url('myorders')); ?>"><i class='bx bx-chevron-left'></i>Mes commandes</a>
                              </div>
                        </div>
                    </div>
                </div>
              </div>
          </section>
        </div>
      </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SB-TECH\sb-tech\resources\views/view.blade.php ENDPATH**/ ?>